//
//  GetIpAddress.h
//  SocketServer
//
//  Created by 李剑钊 on 15/6/16.
//  Copyright (c) 2015年 sunli. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GetIpAddress : NSObject

+ (NSString *)getDeviceIpAddress;

@end
